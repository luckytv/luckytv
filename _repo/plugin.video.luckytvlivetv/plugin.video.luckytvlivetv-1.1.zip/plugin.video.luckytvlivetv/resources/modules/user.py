import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLmx1Y2t5dHZsaXZldHY=')

name = b.b64decode('W0NPTE9SIHJlZF1MdWNreVR2IExpdmVUdlsvQ09MT1Jd')

#host = b.b64decode('aHR0cDovLzE5NS4xODEuMTY5Ljg1')
host = b.b64decode('aHR0cDovL2xpdmUubHVja3l0di5vcmc=')
port = b.b64decode('MjU0NjE=')