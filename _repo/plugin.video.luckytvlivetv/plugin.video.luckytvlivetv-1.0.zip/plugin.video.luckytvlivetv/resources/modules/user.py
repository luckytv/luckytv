import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLmx1Y2t5dHZsaXZldHY=')

name = b.b64decode('W0NPTE9SIHJlZF1MdWNreVR2IExpdmVUdlsvQ09MT1Jd')

#host = b.b64decode('aHR0cDovLzE0NC4yMTcuNzguNzg=')
host = b.b64decode('aHR0cDovL2xpdmUudGhlY2FibGVndXl0di5jb20=')
port = b.b64decode('MjU0NjE=')